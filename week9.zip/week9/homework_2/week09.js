
let time;

time = 34;

console.log (`Старт поездки. Осталось минут: ${time}`);

time = time - 15;

console.log (`Немного сторис в соцсетях. Осталось минут: ${time}`);

time = time - 10;

console.log (`Немного не новостей, но событий. Осталось минут: ${time}`);

time = 0;

console.log (`Вы приехали. Добро пожаловать в Москву.`);
